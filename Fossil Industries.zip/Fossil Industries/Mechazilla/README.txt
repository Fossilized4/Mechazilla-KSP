COMPATABILITY:

- This mod works with stock Kerbal Space Program + Realism Overhaul (1.10.1 is the only version tested)

DEPENDENCIES:

- Dependencies will come in future updates; currently none

INSTALLATION:

- Take the "Mechazilla" folder out of the "GameData" which is in the downloaded zip and place it in the "GameData" folder which is in your KSP directory.

	OR:

- Replace the "GameData" folder in your KSP directory with the "GameData" folder in the downloaded zip.
